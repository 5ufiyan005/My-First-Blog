export type ThemeMode = 'cream' | 'light' | 'slate';

export interface ReadingPreferences {
  theme: ThemeMode;
  fontSize: 'sm' | 'base' | 'lg' | 'xl';
}

export interface Bookmark {
  id: string;
  sectionTitle: string;
  text: string;
  timestamp: string;
}

export interface QuizQuestion {
  id: string;
  category: 'technical' | 'cognitive' | 'social' | 'adaptive';
  question: string;
  options: {
    text: string;
    score: number;
    feedback: string;
  }[];
}

export interface SkillItem {
  id: string;
  name: string;
  category: string;
  description: string;
  relevance: 'High' | 'Medium' | 'Critical';
}
