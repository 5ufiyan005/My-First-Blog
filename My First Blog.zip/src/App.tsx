import React, { useState, useEffect, useRef } from 'react';
import { BLOG_SECTIONS, JOURNAL_METADATA, CAREER_PATHWAYS } from './data/blogContent';
import { Bookmark as BookmarkType, ReadingPreferences, ThemeMode } from './types';
import EditorialHeader from './components/EditorialHeader';
import { default as InteractiveTimeline } from './components/InteractiveTimeline';
import { default as InteractiveTracker } from './components/InteractiveTracker';
import { default as ResilienceAssessment } from './components/ResilienceAssessment';
import {
  Bookmark,
  BookmarkCheck,
  BookmarkPlus,
  Trash2,
  Copy,
  ChevronRight,
  Send,
  Mail,
  Quote,
  Sparkles,
  Award,
  BookOpen,
  ArrowRight,
  Info,
  CheckCircle2
} from 'lucide-react';

export default function App() {
  const [preferences, setPreferences] = useState<ReadingPreferences>({
    theme: 'cream',
    fontSize: 'base'
  });
  
  const [bookmarks, setBookmarks] = useState<BookmarkType[]>([]);
  const [isBookmarksOpen, setIsBookmarksOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('introduction');
  const [userNote, setUserNote] = useState('');
  const [notesList, setNotesList] = useState<{ id: string; text: string; date: string }[]>([]);
  const [copiedTakeaway, setCopiedTakeaway] = useState(false);
  const [portfolioContact, setPortfolioContact] = useState({ name: '', email: '', message: '' });
  const [contactSubmitted, setContactSubmitted] = useState(false);

  // Intersection observer to track scrolled section
  const sectionRefs = useRef<{ [key: string]: HTMLElement | null }>({});

  useEffect(() => {
    // Load bookmarks and custom notes from localstorage (robust client-side persistence)
    try {
      const storedBookmarks = localStorage.getItem('editorial_bookmarks');
      if (storedBookmarks) setBookmarks(JSON.parse(storedBookmarks));

      const storedNotes = localStorage.getItem('editorial_notes');
      if (storedNotes) setNotesList(JSON.parse(storedNotes));
    } catch (e) {
      console.warn("Storage reading failed or was blocked in this container.", e);
    }
  }, []);

  const saveBookmarksToLocalStorage = (list: BookmarkType[]) => {
    try {
      localStorage.setItem('editorial_bookmarks', JSON.stringify(list));
    } catch (e) {
      console.warn(e);
    }
  };

  const saveNotesToLocalStorage = (list: { id: string; text: string; date: string }[]) => {
    try {
      localStorage.setItem('editorial_notes', JSON.stringify(list));
    } catch (e) {
      console.warn(e);
    }
  };

  const handleToggleBookmark = (sectionTitle: string, text: string) => {
    const isAlreadyBookmarked = bookmarks.find((b) => b.text === text);
    let newBookmarks: BookmarkType[];
    
    if (isAlreadyBookmarked) {
      newBookmarks = bookmarks.filter((b) => b.text !== text);
    } else {
      newBookmarks = [
        ...bookmarks,
        {
          id: Math.random().toString(36).substr(2, 9),
          sectionTitle,
          text,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ];
    }
    setBookmarks(newBookmarks);
    saveBookmarksToLocalStorage(newBookmarks);
  };

  const handleDeleteBookmark = (id: string) => {
    const updated = bookmarks.filter((b) => b.id !== id);
    setBookmarks(updated);
    saveBookmarksToLocalStorage(updated);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userNote.trim()) return;
    const newNotes = [
      ...notesList,
      {
        id: Math.random().toString(),
        text: userNote.trim(),
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      }
    ];
    setNotesList(newNotes);
    saveNotesToLocalStorage(newNotes);
    setUserNote('');
  };

  const handleDeleteNote = (id: string) => {
    const updated = notesList.filter((n) => n.id !== id);
    setNotesList(updated);
    saveNotesToLocalStorage(updated);
  };

  // Intersection Observer implementation for progress jumphighlight
  useEffect(() => {
    const observers: IntersectionObserver[] = [];

    const observerOption = {
      root: null,
      rootMargin: '-20% 0px -60% 0px',
      threshold: 0
    };

    const handleIntersection = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(handleIntersection, observerOption);
    
    Object.keys(sectionRefs.current).forEach((key) => {
      const el = sectionRefs.current[key];
      if (el) observer.observe(el);
    });

    return () => {
      observer.disconnect();
    };
  }, []);

  const handleCopyTakeaway = () => {
    const summaryText = `The Automated Economy Playbook SUMMARY:\n` +
      `- Pivot value from automated output Creator to strategic System Director.\n` +
      `- Focus training resources on the "Cognitive-Social-Adaptive" skills triad.\n` +
      `- Deconstruct your professional pipeline. Reclaim hours saved to build strategic influence.\n` +
      `Author: ${JOURNAL_METADATA.author}${JOURNAL_METADATA.role ? `, ${JOURNAL_METADATA.role}` : ''}`;
    
    navigator.clipboard.writeText(summaryText);
    setCopiedTakeaway(true);
    setTimeout(() => setCopiedTakeaway(false), 2500);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!portfolioContact.name || !portfolioContact.email || !portfolioContact.message) return;
    setContactSubmitted(true);
    setTimeout(() => {
      setPortfolioContact({ name: '', email: '', message: '' });
      setContactSubmitted(false);
    }, 4000);
  };

  // Map theme variables
  const themeClasses = {
    cream: 'bg-[#FAF6EB] text-[#2C2417] border-stone-200/80 selection:bg-amber-200 selection:text-amber-950',
    light: 'bg-[#FFFFFF] text-[#111111] border-stone-200 selection:bg-sky-100 selection:text-sky-950',
    slate: 'bg-[#0E131F] text-[#E2E8F0] border-slate-800 selection:bg-purple-900 selection:text-purple-100'
  };

  const fontSizes = {
    sm: 'text-sm md:text-base leading-relaxed',
    base: 'text-base md:text-lg leading-relaxed',
    lg: 'text-lg md:text-xl leading-relaxed',
    xl: 'text-xl md:text-2xl leading-relaxed'
  };

  const textContrastColorForTheme = {
    cream: 'text-amber-800',
    light: 'text-blue-700',
    slate: 'text-purple-400'
  };

  const metaTextForTheme = {
    cream: 'text-amber-900/60 font-mono',
    light: 'text-stone-500 font-mono',
    slate: 'text-slate-400 font-mono'
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 font-sans ${themeClasses[preferences.theme]}`}>
      {/* Editorial Navigation Toolbar */}
      <EditorialHeader
        preferences={preferences}
        onPreferenceChange={setPreferences}
        bookmarksCount={bookmarks.length}
        onOpenBookmarks={() => setIsBookmarksOpen(true)}
        onOpenAssessment={() => {
          const el = document.getElementById('skills-assessment-tool');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        activeSection={activeSection}
      />

      {/* Main Column Container */}
      <main className="max-w-4xl mx-auto px-4 md:px-6 pt-12 pb-24">
        {/* Newsroom Header Stamp */}
        <div className="text-center space-y-4 mb-16 animate-fadeIn">
          <div className="inline-block border-y-2 border-stone-800/20 py-1.5 px-6 uppercase tracking-[0.2em] text-[10px] md:text-xs font-mono font-black text-amber-900">
            Special Report Series
          </div>
          
          <h1 className="font-serif text-3xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-balance leading-tight max-w-3xl mx-auto">
            {JOURNAL_METADATA.title}
          </h1>

          <p className="text-lg md:text-xl text-stone-500 max-w-2xl mx-auto leading-relaxed font-sans italic">
            &ldquo;{JOURNAL_METADATA.subtitle}&rdquo;
          </p>

          {/* Author Crest / Metrics Block */}
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 text-xs font-mono py-6 border-t border-b border-stone-200/50 max-w-xl mx-auto">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-stone-900 text-amber-300 flex items-center justify-center font-bold text-xs ring-2 ring-stone-200">
                SM
              </div>
              <div>
                <span className="font-bold block text-stone-900">{JOURNAL_METADATA.author}</span>
                {JOURNAL_METADATA.role && (
                  <span className="text-[10px] text-stone-400 block">{JOURNAL_METADATA.role}</span>
                )}
              </div>
            </div>
            <span className="hidden md:inline text-stone-300">|</span>
            <div className="flex items-center gap-6">
              <div>
                <span className="text-[10px] text-stone-400 block uppercase">Published</span>
                <span className="font-semibold text-stone-700">{JOURNAL_METADATA.publishedDate}</span>
              </div>
              <div>
                <span className="text-[10px] text-stone-400 block uppercase">Time cost</span>
                <span className="font-semibold text-stone-700">{JOURNAL_METADATA.estimatedReadingTime}</span>
              </div>
              <div>
                <span className="text-[10px] text-stone-400 block uppercase">Format</span>
                <span className="font-semibold text-stone-700">Analytical Long-form</span>
              </div>
            </div>
          </div>
        </div>

        {/* Lux Executive Summary Panel */}
        <section className={`rounded-xl border p-6 md:p-8 mb-16 relative overflow-hidden ${
          preferences.theme === 'slate'
            ? 'bg-slate-900 border-slate-800'
            : 'bg-[#fcfaf5]/90 border-amber-900/10'
        }`}>
          <div className="absolute top-0 left-0 w-1.5 h-full bg-amber-700"></div>
          <div className="flex gap-4">
            <Quote className="w-8 h-8 text-amber-700 shrink-0 opacity-40" />
            <div>
              <span className="font-mono text-[9px] uppercase tracking-widest font-bold text-amber-800 block mb-1">
                Executive Synthesis (Synopsis)
              </span>
              <p className="font-serif italic text-base md:text-lg leading-relaxed text-stone-700">
                {JOURNAL_METADATA.executiveSummary}
              </p>
            </div>
          </div>
        </section>

        {/* Dynamic Journalistic Core Content Mapping */}
        <div className="space-y-12">
          {BLOG_SECTIONS.map((section, idx) => {
            const isBookmarkedSection = bookmarks.some((b) => b.sectionTitle === section.title);
            
            return (
              <article
                key={section.id}
                id={section.id}
                ref={(el) => {
                  sectionRefs.current[section.id] = el;
                }}
                className="group relative transition-all duration-300 pt-6 border-t border-stone-200/30 first:border-t-0 first:pt-0"
              >
                {/* Floating Pocket citation clip trigger beside section titles */}
                <div className="absolute -left-12 top-7 hidden xl:flex flex-col gap-1 items-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => handleToggleBookmark(section.title, section.paragraphs[0])}
                    className="p-2 rounded-full border border-stone-300/60 hover:bg-stone-100 hover:text-stone-900 bg-white shadow-xs text-stone-400 cursor-pointer"
                    title="Bookmark Notable Passage"
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Section Header */}
                <header className="mb-4">
                  <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-amber-850 font-semibold mb-1">
                    {section.subtitle}
                  </p>
                  <div className="flex items-center justify-between">
                    <h2 className="font-serif text-xl md:text-3xl font-bold tracking-tight text-balance group-hover:text-amber-900 transition-colors">
                      {section.title}
                    </h2>
                    
                    {/* Tiny responsive bookmark toggle */}
                    <button
                      onClick={() => handleToggleBookmark(section.title, section.paragraphs[0])}
                      className="p-1 px-2.5 rounded border border-stone-200 bg-stone-50/50 hover:bg-stone-100 hover:text-stone-900 text-stone-400 text-[10px] font-mono flex items-center gap-1 xl:hidden cursor-pointer"
                    >
                      {bookmarks.some((b) => b.sectionTitle === section.title) ? (
                        <>
                          <BookmarkCheck className="w-3" />
                          <span>Saved</span>
                        </>
                      ) : (
                        <>
                          <BookmarkPlus className="w-3" />
                          <span>Save Clip</span>
                        </>
                      )}
                    </button>
                  </div>
                </header>

                {/* Paragraph Content Section with Drops Cap styling on the absolute first paragraph of introductory text */}
                <div className={`space-y-6 font-serif ${fontSizes[preferences.fontSize]}`}>
                  {section.paragraphs.map((p, pIdx) => (
                    <p
                      key={pIdx}
                      className={`leading-relaxed text-balance relative ${
                        idx === 0 && pIdx === 0
                          ? 'first-letter:text-5xl first-letter:float-left first-letter:font-extrabold first-letter:font-serif first-letter:mr-2.5 first-letter:text-stone-900 first-letter:mt-1.5'
                          : ''
                      }`}
                    >
                      {p}
                    </p>
                  ))}
                </div>

                {/* Pull Quote Block */}
                {section.keyQuote && (
                  <div className="my-8 md:my-12 p-6 md:p-8 bg-stone-50/65 border-y border-stone-200/50 md:mx-6 flex flex-col items-center justify-center text-center">
                    <Quote className="w-6 h-6 text-amber-700/60 mb-3" />
                    <blockquote className="font-serif italic text-base md:text-xl text-stone-800 leading-relaxed max-w-xl">
                      &ldquo;{section.keyQuote.text}&rdquo;
                    </blockquote>
                    <cite className="block text-xs font-mono uppercase text-stone-500 tracking-wider mt-3.5 not-italic">
                      — {section.keyQuote.author}
                    </cite>
                  </div>
                )}

                {/* Inject visual interactive timelines / analytics calculators natively between reading blocks */}
                {section.id === 'how-ai-transforms' && (
                  <div className="my-8 md:my-14 font-sans">
                    <InteractiveTimeline />
                  </div>
                )}

                {section.id === 'opportunities' && (
                  <div className="my-8 md:my-14 font-sans">
                    <InteractiveTracker />
                  </div>
                )}

                {section.id === 'future-skills' && (
                  <div className="my-8 md:my-14 font-sans">
                    <ResilienceAssessment theme={preferences.theme} />
                  </div>
                )}
              </article>
            );
          })}
        </div>

        {/* Infographic Summary takeaway certificate */}
        <section className="bg-stone-950 font-sans text-stone-100 rounded-xl my-16 p-6 md:p-8 border border-stone-800 relative overflow-hidden" id="playbook-summary">
          <div className="absolute top-0 right-0 p-8 opacity-5 text-amber-500">
            <Sparkles className="w-40 h-40" />
          </div>

          <div className="relative z-10 flex flex-col md:flex-row gap-6 justify-between items-start">
            <div className="space-y-3.5">
              <span className="text-[9px] uppercase font-mono tracking-widest font-semibold px-2 py-0.5 bg-amber-950/40 text-amber-300 border border-amber-900/40 rounded">
                Executive Playbook Summary
              </span>
              <h3 className="font-serif text-xl md:text-2xl font-bold">
                Summary of What Lies Ahead for the Workforce
              </h3>
              <p className="text-xs text-stone-400 leading-relaxed max-w-xl">
                The Cognitive Threshold represents a restructuring of workflows, not an end-state. The key strategies to prepare yourself for the automated economy are:
              </p>
              
              <ul className="space-y-2.5 text-xs text-stone-300 font-sans list-none pl-0">
                <li className="flex gap-2 items-start">
                  <div className="w-4.5 h-4.5 rounded-full bg-emerald-900/80 text-emerald-300 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">1</div>
                  <span><strong>The Hybrid Leverage</strong>: Pivot value from raw volume task executioner into critical system orchestrator. Use tools as your interns.</span>
                </li>
                <li className="flex gap-2 items-start">
                  <div className="w-4.5 h-4.5 rounded-full bg-emerald-900/80 text-emerald-300 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">2</div>
                  <span><strong>The Skills Safeguard</strong>: Prioritize skill training pathways that computers struggle to scale—critical verification, emotional counseling & dynamic negotiation.</span>
                </li>
                <li className="flex gap-2 items-start">
                  <div className="w-4.5 h-4.5 rounded-full bg-emerald-900/80 text-emerald-300 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">3</div>
                  <span><strong>Deconstruct & Scale</strong>: Break your profession into task categories. Automate the predictable boilerplate, then double down on strategic creative relationships.</span>
                </li>
              </ul>
            </div>

            <div className="flex flex-col gap-2 shrink-0 w-full sm:w-auto bg-stone-900 border border-stone-850 p-4.5 rounded-lg">
              <span className="text-[9px] font-mono uppercase text-stone-500">Resource takeaways</span>
              <button
                onClick={handleCopyTakeaway}
                className="flex items-center justify-center gap-2 px-3.5 py-2 rounded text-xs font-mono bg-white text-stone-950 hover:bg-stone-100 cursor-pointer transition-all w-full"
                id="copy-playbook-citation"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copiedTakeaway ? 'Copied Citation!' : 'Copy Citation Text'}</span>
              </button>
              <div className="text-[10px] text-stone-500 text-center font-mono">
                Perfect to add as a citation for your portfolio case studies.
              </div>
            </div>
          </div>
        </section>

        {/* Portfolio Owner & Strategic Context Box */}
        <footer className="border-t border-stone-200/50 pt-10 mt-16 text-xs text-stone-400">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start mb-12">
            <div className="md:col-span-7 space-y-4">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-stone-400" />
                <span className="font-mono font-bold uppercase text-stone-600 tracking-wider">
                  Portfolio Showcase Project
                </span>
              </div>
              <p className="font-sans leading-relaxed text-stone-500">
                This project showcases modern web development practices, including TypeScript, responsive design, and interactive user interface components, while presenting an in-depth analysis of AI's impact on future jobs.
              </p>
              
              <div className="flex gap-3.5 text-xs font-mono text-stone-600">
                <span className="text-stone-400">sufiyanahmedmalik005@gmail.com</span>
              </div>
            </div>

            {/* Interactive direct-portfolio email client mock (highly engaging) */}
            <div className="md:col-span-5 bg-stone-50 border border-stone-200/60 p-4 rounded-lg">
              <h5 className="font-serif font-bold text-stone-900 mb-2 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-indigo-700" />
                <span>Message sufiyanahmedmalik005</span>
              </h5>
              
              {contactSubmitted ? (
                <div className="bg-emerald-50 border border-emerald-200/50 p-4 rounded-lg text-emerald-900 text-center space-y-1">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 mx-auto" />
                  <p className="font-bold text-xs mt-1">Proposal Transmission Success!</p>
                  <p className="text-[10px] text-emerald-700">Thank you for evaluating this portfolio piece.</p>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-2.5">
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="My Name"
                      required
                      value={portfolioContact.name}
                      onChange={(e) => setPortfolioContact({ ...portfolioContact, name: e.target.value })}
                      className="border border-stone-200/70 p-2 text-stone-800 text-[11px] rounded bg-white w-full focus:outline-indigo-500 focus:outline"
                    />
                    <input
                      type="email"
                      placeholder="email@domain.com"
                      required
                      value={portfolioContact.email}
                      onChange={(e) => setPortfolioContact({ ...portfolioContact, email: e.target.value })}
                      className="border border-stone-200/70 p-2 text-stone-800 text-[11px] rounded bg-white w-full focus:outline-indigo-500 focus:outline"
                    />
                  </div>
                  <textarea
                    placeholder="Inquire about custom developments or engineering collaborations..."
                    required
                    rows={2}
                    value={portfolioContact.message}
                    onChange={(e) => setPortfolioContact({ ...portfolioContact, message: e.target.value })}
                    className="border border-stone-200/70 p-2 text-stone-800 text-[11px] rounded bg-white w-full h-14 resize-none focus:outline-indigo-500 focus:outline"
                  />
                  <button
                    type="submit"
                    className="w-full bg-stone-900 text-white p-2 rounded hover:bg-stone-800 text-[10px] font-mono tracking-widest uppercase font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3 h-3" />
                    <span>Send Proposal message</span>
                  </button>
                </form>
              )}
            </div>
          </div>

          <div className="text-center font-mono text-[10px] text-stone-400 border-t border-stone-200/30 pt-6">
            © 2026 The Future of Jobs Editorial | Handcoded by Sufiyan Ahmed Malik. All rights reserved.
          </div>
        </footer>
      </main>

      {/* Slide-out Drawer Panel: Bookmarks and Custom Research Notes */}
      <div className={`fixed inset-0 z-50 flex justify-end bg-black/40 transition-opacity duration-300 ${
        isBookmarksOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
      }`}>
        {/* Backdrop closer click */}
        <div className="flex-grow" onClick={() => setIsBookmarksOpen(false)}></div>

        {/* Content sheet */}
        <div className={`w-full max-w-md bg-stone-50 border-l border-stone-200 h-full flex flex-col justify-between shadow-2xl transition-transform duration-300 overflow-hidden ${
          isBookmarksOpen ? 'translate-x-0' : 'translate-x-full'
        }`}>
          {/* Header */}
          <div className="bg-white p-4.5 border-b border-stone-200/60 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-amber-700 fill-amber-50" />
              <div>
                <h4 className="font-serif text-sm font-bold text-stone-900 leading-tight">Research Notebook Workspace</h4>
                <p className="text-[10px] text-stone-400 font-mono">Capture and refine core insights dynamically</p>
              </div>
            </div>
            <button
              onClick={() => setIsBookmarksOpen(false)}
              className="text-stone-400 hover:text-stone-950 font-mono text-xs p-1 cursor-pointer"
            >
              Close [X]
            </button>
          </div>

          {/* Bookmarked Highlights & Custom Comments Workspace scrollable body */}
          <div className="flex-grow overflow-y-auto p-4 md:p-5 space-y-6">
            
            {/* Captured Citations Section */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-stone-500">
                  Notable Citations ({bookmarks.length})
                </span>
                {bookmarks.length > 0 && (
                  <button
                    onClick={() => {
                      setBookmarks([]);
                      saveBookmarksToLocalStorage([]);
                    }}
                    className="text-[9px] font-mono text-rose-600 hover:underline cursor-pointer"
                  >
                    Clear All Clips
                  </button>
                )}
              </div>

              {bookmarks.length === 0 ? (
                <div className="border border-dashed border-stone-300 rounded-lg p-6 bg-white text-center space-y-2">
                  <BookmarkCheck className="w-8 h-8 text-stone-300 mx-auto opacity-70" />
                  <p className="text-xs font-serif italic text-stone-500">No citations clipped yet.</p>
                  <p className="text-[10px] text-stone-400 font-sans leading-relaxed">
                    Hover on sections in the article or look for "Save Slip" icons to clip quotes for your portfolio briefings directly.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {bookmarks.map((b) => (
                    <div
                      key={b.id}
                      className="bg-white border rounded-lg p-3.5 text-xs shadow-xs border-stone-200/80 group/clip relative transition-all"
                    >
                      <button
                        onClick={() => handleDeleteBookmark(b.id)}
                        className="absolute top-2 right-2 p-1 text-stone-400 hover:text-rose-600 opacity-0 group-hover/clip:opacity-100 transition-opacity rounded cursor-pointer"
                        title="Delete clip"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-[9px] font-mono text-amber-850 uppercase font-semibold block mb-1">
                        {b.sectionTitle} • <span className="opacity-60">{b.timestamp}</span>
                      </span>
                      <p className="font-serif italic text-stone-700 leading-relaxed pr-5">
                        &ldquo;{b.text}&rdquo;
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* User Custom Notes Box widget */}
            <div className="space-y-4 pt-4 border-t border-stone-200/60">
              <div className="flex justify-between items-center">
                <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-stone-500">
                  Custom Strategic Notes ({notesList.length})
                </span>
              </div>

              <form onSubmit={handleAddNote} className="space-y-2 bg-white p-3.5 rounded-lg border border-stone-200/50">
                <textarea
                  placeholder="Record custom thoughts on job transition metrics or list personal reskilling targets..."
                  rows={3}
                  value={userNote}
                  onChange={(e) => setUserNote(e.target.value)}
                  className="w-full border border-stone-200/70 p-2.5 text-stone-850 text-xs rounded bg-stone-50/50 focus:outline-amber-600"
                />
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={!userNote.trim()}
                    className={`px-3 py-1.5 rounded font-mono text-[10px] uppercase tracking-wider cursor-pointer ${
                      userNote.trim()
                        ? 'bg-stone-900 text-white hover:bg-stone-800'
                        : 'bg-stone-100 text-stone-400 cursor-not-allowed'
                    }`}
                  >
                    Save Note
                  </button>
                </div>
              </form>

              {notesList.length > 0 && (
                <div className="space-y-2">
                  {notesList.map((n) => (
                    <div key={n.id} className="bg-[#FAF8F3] border border-amber-900/10 rounded-lg p-3 text-xs flex justify-between items-start gap-3">
                      <div>
                        <p className="text-stone-700 font-sans leading-relaxed">{n.text}</p>
                        <span className="text-[9px] text-stone-400 font-mono mt-1 block">{n.date}</span>
                      </div>
                      <button
                        onClick={() => handleDeleteNote(n.id)}
                        className="text-stone-400 hover:text-rose-600 p-0.5 cursor-pointer"
                        title="Delete note"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

          {/* Notebook Footer */}
          <div className="bg-white p-4 border-t border-stone-200/60 text-[10px] text-stone-400 text-center font-mono">
            Research stored locally on your device for fast portfolio evaluation.
          </div>
        </div>
      </div>
    </div>
  );
}
