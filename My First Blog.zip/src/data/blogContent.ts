export interface BlogSection {
  id: string;
  title: string;
  subtitle?: string;
  paragraphs: string[];
  keyQuote?: {
    text: string;
    author: string;
  };
}

export interface CareerPathway {
  title: string;
  description: string;
  growth: string;
  skillsRequired: string[];
}

export const JOURNAL_METADATA = {
  title: "The Future of Jobs: How AI is Changing Our Work",
  subtitle: "AI is changing from a simple tool into a work partner. Here is a simple guide on what this means for your career, what skills you need, and how to get ready.",
  author: "Sufiyan Ahmed Malik",
  role: "",
  publishedDate: "June 2026",
  estimatedReadingTime: "5 min read",
  executiveSummary: "AI will not simply replace all human workers. Instead, it will change the tasks we do every day. People who do well in this new era will be those who learn how to manage AI tools using good judgment, clear communication, and human empathy."
};

export const BLOG_SECTIONS: BlogSection[] = [
  {
    id: "introduction",
    title: "Introduction: A New Era of Work",
    subtitle: "How machines are changing our daily tasks",
    paragraphs: [
      "For a long time, machines helped us with physical work—like steam engines and assembly lines. Later, computers helped us keep records and do math faster. Today, we are entering a new era where computers are starting to help us with thinking and writing.",
      "Artificial Intelligence (AI) can now understand tricky requests, write texts, and learn patterns on its own. Because of this, we need to ask a new question: not 'Will AI take my job?', but 'How will AI change the way I work?'",
      "We should look at this change clearly. It is not something to fear, but it is something we need to understand so we can prepare ourselves for the future."
    ],
    keyQuote: {
      text: "Old machines replaced physical strength. Computers replaced manual math. But AI is the first tool that works directly with human decision-making.",
      author: "Dr. Aris Thorne"
    }
  },
  {
    id: "what-is-ai",
    title: "1. What is AI and How Does It Work?",
    subtitle: "Understanding the basics without the hype",
    paragraphs: [
      "To understand how AI affects jobs, we must look past complex tech terms. Modern AI is not a living or thinking machine. At its core, it is a very fast computer program that learns from examples of human work.",
      "Today, AI can do more than answer simple questions. It can write code, create pictures, and run other software tools to finish multi-step projects. We call these helpful tools 'AI agents'.",
      "AI does not usually replace an entire job. This is because a job is made of many tiny tasks. AI changes these tiny tasks instead of replacing the whole job. This means your daily work will change, but your career will likely still exist."
    ]
  },
  {
    id: "how-ai-transforms",
    title: "2. The Split: How AI Changes Our Tasks",
    subtitle: "Replacing repetitive paperwork vs keeping human value",
    paragraphs: [
      "Most stories about AI say that a machine will take over your whole job. But the truth is more simple: AI takes over specific, repetitive tasks, not your entire job.",
      "Think about a lawyer. A lawyer writes basic contract drafts, reads old files, talks to clients, and negotiates deals. Writing standard drafts and looking up old files are repetitive tasks. AI can do these in seconds.",
      "However, talking to clients and negotiating deals requires real human trust and feelings. So, the lawyer is not replaced. Instead, they spend less time on paperwork and more time helping their clients directly."
    ]
  },
  {
    id: "opportunities",
    title: "3. The Bright Side: Better Tools and New Careers",
    subtitle: "Becoming an AI-guided professional",
    paragraphs: [
      "While change can feel fast, AI also brings great opportunities. It is creating new types of jobs that did not exist in the past.",
      "We now need AI Managers, Prompt Writers, and Safety Auditors. These jobs do not require advanced math degrees. They need people who know how to give clear instructions to AI and check its work for mistakes.",
      "AI also makes us much faster. Studies show that people using AI assistants can finish hard tasks up to 40% faster. It acts like an intern, giving everyone their own helper to bring ideas to life quickly."
    ],
    keyQuote: {
      text: "AI will not replace workers, but workers who use AI will replace those who do not.",
      author: "Modern Business Review"
    }
  },
  {
    id: "challenges",
    title: "4. The Hard Part: Challenges We Must Face",
    subtitle: "Why this transition feels fast and difficult",
    paragraphs: [
      "We must also be honest about the challenges. The main problem is how fast this change is happening. Past technology shifts took decades, but software updates happen overnight.",
      "This fast speed causes real problems in three main areas:",
      "First, some jobs are changing too quickly. People working in basic customer support, data entry, and simple writing jobs are seeing less demand. It is hard for these workers to retrain in a short time.",
      "Second, technical skills do not last as long. If AI can write clean web code on demand, simply memorizing coding commands becomes less valuable than knowing how to design a good user experience.",
      "Third, AI can make mistakes. AI models can give wrong answers or continue biases found in their training data. We need human eyes to check everything before making big business choices."
    ]
  },
  {
    id: "future-skills",
    title: "5. Your Career Shield: Key Skills for the Future",
    subtitle: "What humans do best",
    paragraphs: [
      "When AI can write and predict answers cheaply, what human skills are worth the most? The answer is simple: the things computers cannot do.",
      "The first skill is Critical Thinking. AI can generate answers, but it does not know if they are actually true or useful. Humans must check for facts, find mistakes, and make final decisions.",
      "The second skill is Empathy and Connection. No one wants to hear tough news or negotiate a major deal with a robot. Jobs that need true human care, deep listening, and teamwork are very safe.",
      "The third skill is Lifelong Learning. Because tools change so fast, the best skill you can have is being open to learning new things and adapting to new ways of working."
    ]
  },
  {
    id: "conclusion",
    title: "Conclusion: Your Playbook for the AI Era",
    subtitle: "How to stay valuable and succeed",
    paragraphs: [
      "The rise of AI is not the end of human work. It is the end of boring, repetitive tasks. By taking over the tedious parts of our day, AI lets us focus on creativity, strategy, and helping others.",
      "To succeed, you should stop thinking like a simple 'doer' and start thinking like a 'director' or 'manager'. Treat AI like a very smart intern. Let it write the drafts and count the numbers, then use your human experience to make it perfect.",
      "The future does not belong to the computer, nor does it belong to people who ignore technology. It belongs to those who learn to work side-by-side with AI while keeping their human touch."
    ]
  }
];

export const WORKPLACE_TIMELINE_STAGES = [
  {
    era: "Industrial Era (1780 - 1910)",
    coreTech: "Steam Engine, Assembly Line",
    workforceImpact: "Replaced manual crafts with machines. Moved physical labor into factories.",
    humanSurvivalValue: "Operating machinery, physical coordination, and technical engineering."
  },
  {
    era: "The Digital Era (1970 - 2010)",
    coreTech: "Computers, Websites, Databases",
    workforceImpact: "Automated manual math and paper record-keeping. Created modern office desk jobs.",
    humanSurvivalValue: "Computer literacy, basic coding, and structured data entry."
  },
  {
    era: "The AI Era (2020 - Future)",
    coreTech: "AI Agents and Language Models",
    workforceImpact: "Automates repetitive writing, basic coding, and paperwork. Shift from content creator to reviewer.",
    humanSurvivalValue: "Critical thinking, team leadership, prompt management, and human empathy."
  }
];

export const CAREER_PATHWAYS: CareerPathway[] = [
  {
    title: "AI Manager & Workflow Designer",
    description: "People who connect AI tools, databases, and services together to automate simple business work.",
    growth: "+140% annual demand",
    skillsRequired: ["Tool connection", "Command templates", "System checks"]
  },
  {
    title: "AI Trust & Safety Reviewer",
    description: "People who check automated systems for errors, biases, and wrong information before it goes live.",
    growth: "+95% annual demand",
    skillsRequired: ["Ethics checks", "Error auditing", "Simple policy compliance"]
  },
  {
    title: "Human Experience Creator",
    description: "Experts who create in-person services and spaces that explicitly depend on real, friendly human contact.",
    growth: "+60% annual demand",
    skillsRequired: ["Service design", "Community organizing", "Friendly talk"]
  }
];
