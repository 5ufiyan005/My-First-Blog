import React, { useState } from 'react';
import { WORKPLACE_TIMELINE_STAGES } from '../data/blogContent';
import { Archive, Cpu, Sparkles, TrendingUp, HelpCircle } from 'lucide-react';

export default function InteractiveTimeline() {
  const [activeStageIndex, setActiveStageIndex] = useState(2); // Default to cognitive era

  const iconMap = [
    <Archive className="w-5 h-5" />,
    <Cpu className="w-5 h-5" />,
    <Sparkles className="w-5 h-5" />
  ];

  const colors = [
    'border-stone-300 text-stone-700 bg-stone-50',
    'border-sky-300 text-sky-800 bg-sky-50',
    'border-amber-300 text-amber-950 bg-amber-50/70'
  ];

  const badges = [
    'text-stone-600 bg-stone-100',
    'text-sky-800 bg-sky-100',
    'text-amber-900 bg-amber-100 font-semibold border border-amber-200 animate-pulse'
  ];

  return (
    <div className="my-10 bg-stone-50/50 rounded-xl border border-stone-200/60 p-6 md:p-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-amber-800 bg-amber-50 border border-amber-200/50 px-2 py-0.5 rounded-sm">
            Workforce Milestones
          </span>
          <h3 className="font-serif text-xl md:text-2xl font-bold text-stone-900 mt-1.5">
            The History of Automation
          </h3>
          <p className="text-xs text-stone-500 font-sans mt-0.5">
            See how the big changes in history compare to the new AI era.
          </p>
        </div>
        <div className="text-xs font-mono text-stone-400 mt-2 md:mt-0 flex items-center gap-1">
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Major Workplace Shifts</span>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="grid grid-cols-3 gap-2 border-b border-stone-200 pb-4 mb-6">
        {WORKPLACE_TIMELINE_STAGES.map((stage, idx) => (
          <button
            key={idx}
            onClick={() => setActiveStageIndex(idx)}
            className={`flex flex-col md:flex-row items-center gap-2.5 p-3 rounded-lg text-left transition-all cursor-pointer ${
              activeStageIndex === idx
                ? 'bg-stone-900 text-white shadow-md transform -translate-y-0.5'
                : 'bg-white text-stone-600 hover:bg-stone-50 border border-stone-200/70'
            }`}
            id={`timeline-tab-${idx}`}
          >
            <div className={`p-1.5 rounded-md hidden sm:block ${
              activeStageIndex === idx ? 'bg-stone-800 text-amber-200' : 'bg-stone-100 text-stone-500'
            }`}>
              {iconMap[idx]}
            </div>
            <div>
              <p className="text-[9px] uppercase font-mono tracking-tight opacity-70">
                {idx === 0 ? 'Phase I' : idx === 1 ? 'Phase II' : 'Phase III'}
              </p>
              <h4 className="font-serif text-xs md:text-sm font-semibold truncate max-w-[80px] sm:max-w-none">
                {idx === 0 ? 'Industrial' : idx === 1 ? 'Computing' : 'AI Era'}
              </h4>
            </div>
          </button>
        ))}
      </div>

      {/* active stage panel detail */}
      <div className="transition-all duration-300">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-8 space-y-4">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-mono text-xs text-stone-400">Years:</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-mono ${badges[activeStageIndex]}`}>
                  {WORKPLACE_TIMELINE_STAGES[activeStageIndex].era}
                </span>
              </div>
              <h4 className="font-serif text-lg md:text-2xl font-bold text-stone-950 mt-2">
                Core Tech: <span className="font-sans text-amber-900 font-semibold">{WORKPLACE_TIMELINE_STAGES[activeStageIndex].coreTech}</span>
              </h4>
            </div>

            <div className="border-l-2 border-stone-300 pl-4 py-1">
              <p className="text-xs font-mono uppercase text-stone-400 tracking-wider">Workforce Impact</p>
              <p className="text-stone-700 leading-relaxed text-sm md:text-base mt-1">
                {WORKPLACE_TIMELINE_STAGES[activeStageIndex].workforceImpact}
              </p>
            </div>
          </div>

          <div className="md:col-span-4 flex flex-col justify-between bg-white rounded-lg border border-stone-200/50 p-4 shadow-xs">
            <div>
              <div className="flex items-center gap-1 text-xs font-mono text-stone-400 uppercase tracking-widest mb-2">
                <Archive className="w-3.5 h-3.5 text-amber-600" />
                <span>Value Skill</span>
              </div>
              <h5 className="font-serif text-sm font-bold text-stone-900 leading-tight">
                How Workers Stay Valuable
              </h5>
              <p className="text-xs text-stone-500 mt-1">
                The main human capability required to secure success in this era:
              </p>
            </div>

            <div className="bg-amber-50/50 border border-amber-100 rounded p-3.5 mt-4">
              <p className="font-mono font-bold text-amber-950 text-xs tracking-tight">
                {WORKPLACE_TIMELINE_STAGES[activeStageIndex].humanSurvivalValue}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
