import React, { useState } from 'react';
import { Shield, Hammer, Sparkles, Code2, HeartHandshake, Settings, PlayCircle, HelpCircle } from 'lucide-react';

interface SectorImpact {
  id: string;
  name: string;
  icon: React.ReactNode;
  exposureRate: number; // 0 to 100
  amplificationPotential: number; // 0 to 100
  frictionScore: number; // 0 to 100
  primaryTaskAutomated: string;
  primaryHumanValue: string;
  verdict: string;
}

export default function InteractiveTracker() {
  const [selectedSectorId, setSelectedSectorId] = useState('software');
  const [delegatePct, setDelegatePct] = useState(40); // User slides to delegate "routine work"

  const sectors: SectorImpact[] = [
    {
      id: 'software',
      name: 'Software Engineering',
      icon: <Code2 className="w-4 h-4 text-sky-600" />,
      exposureRate: 75,
      amplificationPotential: 90,
      frictionScore: 35,
      primaryTaskAutomated: 'Writing basic code, fixing syntax mistakes, running simple software tests',
      primaryHumanValue: 'Designing total software layout, testing security and trust, understanding what users want',
      verdict: 'Great! Young coders will learn to guide tools faster, and simple tasks will not slow you down anymore.'
    },
    {
      id: 'creative',
      name: 'Creative & Writing',
      icon: <Sparkles className="w-4 h-4 text-purple-600" />,
      exposureRate: 65,
      amplificationPotential: 70,
      frictionScore: 55,
      primaryTaskAutomated: 'Writing first drafts, summarizing articles, organizing web keywords',
      primaryHumanValue: 'Giving a unique style to writing, doing research interviews, telling stories with feelings',
      verdict: 'Balanced. Easy office writing is taken over by AI, but creative writers will find their stories can reach much further with these tools.'
    },
    {
      id: 'medical',
      name: 'Healthcare & Diagnostics',
      icon: <HeartHandshake className="w-4 h-4 text-rose-600" />,
      exposureRate: 45,
      amplificationPotential: 85,
      frictionScore: 80,
      primaryTaskAutomated: 'Reading medical scans, typing doctor notes, creating dosage charts',
      primaryHumanValue: 'Comforting patients, making tough medical choices, talking with compassion',
      verdict: 'Safe. Strict legal rules and the need for human care and trust keep these healthcare roles safe.'
    },
    {
      id: 'physical',
      name: 'Trades & Physical Labor',
      icon: <Hammer className="w-4 h-4 text-amber-600" />,
      exposureRate: 15,
      amplificationPotential: 25,
      frictionScore: 90,
      primaryTaskAutomated: 'Counting supplies, scheduling team work, sending bills',
      primaryHumanValue: 'Doing actual physical repairs, fixing pipes, solving unpredictable handiwork issues',
      verdict: 'Safe. Building robots that can fix home plumbing or pipes is very hard and way too expensive.'
    },
    {
      id: 'finance',
      name: 'Financial Advisory',
      icon: <Shield className="w-4 h-4 text-emerald-600" />,
      exposureRate: 70,
      amplificationPotential: 75,
      frictionScore: 60,
      primaryTaskAutomated: 'Managing simple stock portfolios, detecting fraud maths, doing tax calculations',
      primaryHumanValue: 'Helping families align their life savings, coaching clients when markets drop, building personal trust',
      verdict: 'Changing. Computers will handle standard calculations, but friendly financial coaches will become even more important.'
    }
  ];

  const activeSector = sectors.find(s => s.id === selectedSectorId) || sectors[0];

  // Algorithmic calculation of simulated outcomes
  // delegatePct runs from 10 to 90.
  // Calculated Hour Saved = (ExposureRate/100) * delegatePct * 0.4 (hours saved per week basis on a 40-hour week)
  const hoursSavedPerWeek = Number(((activeSector.exposureRate / 100) * (delegatePct / 100) * 40).toFixed(1));
  const qualityMultiplier = Number((1 + (activeSector.amplificationPotential / 100) * (delegatePct / 120)).toFixed(2));
  const vulnerabilityScale = Math.max(
    10,
    Math.round(activeSector.exposureRate - (100 - activeSector.frictionScore) * (1 - delegatePct / 100))
  );

  return (
    <div className="bg-stone-900 text-stone-100 rounded-xl my-10 p-6 md:p-8 border border-stone-800 shadow-xl overflow-hidden relative">
      {/* Visual decorative ambient element */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-stone-800 rounded-full filter blur-[100px] opacity-25 -z-0"></div>

      <div className="relative z-10">
        <div className="mb-6">
          <span className="text-[9px] uppercase font-mono tracking-widest font-semibold px-2 py-0.5 rounded-sm bg-stone-800 text-stone-400 border border-stone-700">
            Interactive Tool
          </span>
          <h3 className="font-serif text-xl md:text-2xl font-bold text-stone-100 mt-2">
            AI Task Simulator
          </h3>
          <p className="text-xs text-stone-400 mt-1">
            Chose a job. Slide the bar to see how much time you save and how much you might need to learn.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Sectors sidepicker list */}
          <div className="lg:col-span-4 flex flex-col gap-2">
            <span className="text-[10px] uppercase font-mono text-stone-500 tracking-wider">Choose a Job</span>
            {sectors.map((sec) => (
              <button
                key={sec.id}
                onClick={() => setSelectedSectorId(sec.id)}
                className={`p-3 rounded-lg text-left text-xs font-sans border flex items-center justify-between transition-all cursor-pointer ${
                  selectedSectorId === sec.id
                    ? 'bg-stone-100 text-stone-900 border-white shadow-md'
                    : 'bg-stone-900 border-stone-800 text-stone-300 hover:bg-stone-800/80 hover:text-white'
                }`}
                id={`sector-tab-${sec.id}`}
              >
                <div className="flex items-center gap-2.5">
                  <div className={`p-1.5 rounded-md ${
                    selectedSectorId === sec.id ? 'bg-stone-200' : 'bg-stone-800'
                  }`}>
                    {sec.icon}
                  </div>
                  <span className="font-medium">{sec.name}</span>
                </div>
                <span className="font-mono text-[10px] opacity-60">
                  {sec.exposureRate}% Change
                </span>
              </button>
            ))}
          </div>

          {/* Interactive slider & simulator values */}
          <div className="lg:col-span-8 bg-stone-800/40 rounded-xl p-5 border border-stone-800 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-mono text-stone-400 uppercase tracking-widest">
                  Simulator Settings
                </span>
                <span className="text-xs font-serif italic text-amber-200/90 font-semibold">
                  Analyzing: {activeSector.name}
                </span>
              </div>

              {/* Slider panel */}
              <div className="bg-stone-900/60 p-4 rounded-lg border border-stone-800/60 mb-6">
                <div className="flex justify-between items-center mb-2.5">
                  <label className="text-[11px] font-mono text-stone-300 flex items-center gap-1">
                    <Settings className="w-3.5 h-3.5 text-amber-500 animate-spin" />
                    <span>Delegation of Routine Work:</span>
                  </label>
                  <span className="text-sm font-mono font-bold text-amber-300 bg-amber-950/55 px-2 py-0.5 rounded border border-amber-900/50">
                    {delegatePct}%
                  </span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="90"
                  value={delegatePct}
                  onChange={(e) => setDelegatePct(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer h-1.5 bg-stone-800 rounded-lg appearance-none"
                  id="delegate-range-slider"
                />
                <div className="flex justify-between text-[9px] font-mono text-stone-500 mt-1.5 uppercase">
                  <span>Basic Helper</span>
                  <span>AI Assistant</span>
                  <span>Team Orchestrator</span>
                </div>
              </div>

              {/* Quantitative impact cards */}
              <div className="grid grid-cols-3 gap-3 mb-6">
                <div className="bg-stone-900/40 p-3 rounded-lg border border-stone-800">
                  <p className="text-[9px] font-mono text-stone-400 uppercase">Hours Saved</p>
                  <p className="font-mono text-2xl font-bold text-emerald-400 mt-1">
                    +{hoursSavedPerWeek}h
                  </p>
                  <p className="text-[9px] text-stone-500 font-mono">per week saved from paperwork</p>
                </div>
                <div className="bg-stone-900/40 p-3 rounded-lg border border-stone-800">
                  <p className="text-[9px] font-mono text-stone-400 uppercase">Work Speed Boost</p>
                  <p className="font-mono text-2xl font-bold text-sky-400 mt-1">
                    {qualityMultiplier}x
                  </p>
                  <p className="text-[9px] text-stone-500 font-mono">extra work you can do now</p>
                </div>
                <div className="bg-stone-900/40 p-3 rounded-lg border border-stone-800">
                  <p className="text-[9px] font-mono text-stone-400 uppercase">Need to Learn New Skills</p>
                  <p className={`font-mono text-2xl font-bold mt-1 ${
                    vulnerabilityScale < 40 ? 'text-emerald-400' : vulnerabilityScale < 65 ? 'text-amber-400' : 'text-rose-500'
                  }`}>
                    {vulnerabilityScale}%
                  </p>
                  <p className="text-[9px] text-stone-500 font-mono">how much you need to learn</p>
                </div>
              </div>

              {/* Qualitative diagnostics */}
              <div className="space-y-3.5 border-t border-stone-800 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="text-xs">
                    <p className="font-mono text-[9px] text-stone-400 uppercase mb-1">Tasks AI Does</p>
                    <p className="text-stone-300 font-serif leading-relaxed italic bg-stone-900/30 p-2.5 rounded border border-stone-800/40">
                      &ldquo;{activeSector.primaryTaskAutomated}&rdquo;
                    </p>
                  </div>
                  <div className="text-xs">
                    <p className="font-mono text-[9px] text-amber-400 uppercase mb-1">Tasks Humans Do Best</p>
                    <p className="text-indigo-200 font-serif leading-relaxed italic bg-indigo-950/15 p-2.5 rounded border border-indigo-900/25">
                      &ldquo;{activeSector.primaryHumanValue}&rdquo;
                    </p>
                  </div>
                </div>

                <div className="bg-stone-900/70 p-3.5 rounded-lg border border-stone-800 text-xs">
                  <span className="font-mono font-semibold text-amber-200 block text-[9px] uppercase tracking-wider mb-0.5">
                    Our Summary
                  </span>
                  <p className="text-stone-300 font-sans leading-relaxed">
                    {activeSector.verdict}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
