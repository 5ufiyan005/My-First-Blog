import React, { useEffect, useState } from 'react';
import { Type, Bookmark, Play, Pause, Compass, Newspaper, AlignLeft, Volume2, HelpCircle } from 'lucide-react';
import { ThemeMode, ReadingPreferences } from '../types';
import { JOURNAL_METADATA } from '../data/blogContent';

interface EditorialHeaderProps {
  preferences: ReadingPreferences;
  onPreferenceChange: (prefs: ReadingPreferences) => void;
  bookmarksCount: number;
  onOpenBookmarks: () => void;
  onOpenAssessment: () => void;
  activeSection: string;
}

export default function EditorialHeader({
  preferences,
  onPreferenceChange,
  bookmarksCount,
  onOpenBookmarks,
  onOpenAssessment,
  activeSection
}: EditorialHeaderProps) {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [speechInstance, setSpeechInstance] = useState<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        setScrollProgress((window.scrollY / totalScroll) * 100);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSpeech = () => {
    if ('speechSynthesis' in window) {
      if (isSynthesizing) {
        window.speechSynthesis.cancel();
        setIsSynthesizing(false);
      } else {
        const textToRead = `${JOURNAL_METADATA.title}. Executive Summary: ${JOURNAL_METADATA.executiveSummary}`;
        const utterance = new SpeechSynthesisUtterance(textToRead);
        utterance.rate = 0.95;
        utterance.pitch = 1.0;
        
        utterance.onend = () => {
          setIsSynthesizing(false);
        };
        utterance.onerror = () => {
          setIsSynthesizing(false);
        };

        setSpeechInstance(utterance);
        setIsSynthesizing(true);
        window.speechSynthesis.speak(utterance);
      }
    } else {
      alert("Text-to-speech is not fully supported in this browser environment.");
    }
  };

  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const setFontSize = (size: 'sm' | 'base' | 'lg' | 'xl') => {
    onPreferenceChange({ ...preferences, fontSize: size });
  };

  const setTheme = (theme: ThemeMode) => {
    onPreferenceChange({ ...preferences, theme });
  };

  const sections = [
    { id: 'introduction', label: 'Intro' },
    { id: 'what-is-ai', label: '1. What is AI' },
    { id: 'how-ai-transforms', label: '2. Tasks' },
    { id: 'opportunities', label: '3. Opportunities' },
    { id: 'challenges', label: '4. Challenges' },
    { id: 'future-skills', label: '5. Skills' },
    { id: 'conclusion', label: 'Guide' }
  ];

  return (
    <>
      {/* Top Banner indicating Journal Quality */}
      <header className="border-b border-stone-200/50 bg-stone-50 md:py-2 text-[10px] tracking-widest text-stone-500 uppercase font-mono px-4 flex justify-between items-center z-40 relative">
        <div className="flex items-center gap-2">
          <Newspaper className="w-3.5 h-3.5 text-stone-600" />
          <span>Sufiyan's Career Blog</span>
        </div>
        <div className="hidden md:flex gap-4">
          <span>June 2026</span>
          <span>•</span>
          <span>Simple Reading Guide</span>
        </div>
        <button
          onClick={onOpenAssessment}
          className="flex items-center gap-1.5 font-bold hover:text-amber-800 transition-colors cursor-pointer text-amber-900"
          id="btn-nav-assessment"
        >
          <HelpCircle className="w-3 h-3 text-amber-700 animate-pulse" />
          <span>Take Career Assessment Quiz</span>
        </button>
      </header>

      {/* Main sticky reading controller bar */}
      <nav className="sticky top-0 z-50 backdrop-blur-md bg-opacity-90 border-b transition-colors duration-300 border-stone-200/50 bg-white/95 text-stone-900 pr-4 pl-4 py-3 flex flex-wrap gap-4 justify-between items-center">
        {/* Logo and Estimated Time */}
        <div className="flex items-center gap-3">
          <div className="bg-stone-900 text-white font-serif px-2.5 py-1 text-base font-bold tracking-tight rounded-sm flex items-center justify-center">
            S
          </div>
          <div>
            <h1 className="font-serif font-bold text-sm tracking-tight hidden sm:block md:text-base">
              The Future of Jobs
            </h1>
            <p className="text-[10px] text-stone-500 font-mono flex items-center gap-1">
              <span>{JOURNAL_METADATA.estimatedReadingTime}</span>
              <span>•</span>
              <span className="text-stone-700 font-medium">By {JOURNAL_METADATA.author}</span>
            </p>
          </div>
        </div>

        {/* Jumplinks indicator (Visible on desktop) */}
        <div className="hidden lg:flex items-center gap-3 text-xs font-mono text-stone-600">
          <Compass className="w-3.5 h-3.5 text-stone-400" />
          <ul className="flex gap-2.5">
            {sections.map((sec) => (
              <li key={sec.id}>
                <a
                  href={`#${sec.id}`}
                  className={`px-2 py-1 rounded transition-all hover:text-stone-950 ${
                    activeSection === sec.id
                      ? 'bg-stone-100 text-stone-950 font-semibold border border-stone-200'
                      : ''
                  }`}
                >
                  {sec.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Controls block */}
        <div className="flex items-center gap-4.5">
          {/* TTS Audio Reader */}
          <button
            onClick={handleSpeech}
            className={`flex items-center gap-2 text-xs font-serif px-2.5 py-1.5 rounded-full border transition-all cursor-pointer ${
              isSynthesizing
                ? 'bg-amber-100 border-amber-300 text-amber-900 font-medium animate-pulse'
                : 'border-stone-200 bg-stone-50 text-stone-700 hover:bg-stone-100'
            }`}
            title="Listen to Executive Summary"
            id="tts-button"
          >
            <Volume2 className="w-3.5 h-3.5 text-stone-600" />
            <span className="hidden sm:inline">
              {isSynthesizing ? 'Reading Summary' : 'Listen'}
            </span>
            {isSynthesizing ? (
              <span className="flex gap-0.5 items-end h-2">
                <span className="bg-amber-600 w-0.5 h-full animate-bounce"></span>
                <span className="bg-amber-600 w-0.5 h-3/5 animate-bounce [animation-delay:0.1s]"></span>
                <span className="bg-amber-600 w-0.5.5 h-4/5 animate-bounce [animation-delay:0.2s]"></span>
              </span>
            ) : null}
          </button>

          {/* Theme Switchers */}
          <div className="flex items-center gap-1 bg-stone-100 p-0.5 rounded border border-stone-200/50">
            <button
              onClick={() => setTheme('cream')}
              className={`px-2 py-1 text-xs font-sans rounded transition-all cursor-pointer ${
                preferences.theme === 'cream'
                  ? 'bg-amber-50 text-amber-950 font-medium shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
              title="Warm Cream Contrast"
              id="theme-cream-btn"
            >
              Crm
            </button>
            <button
              onClick={() => setTheme('light')}
              className={`px-2 py-1 text-xs font-sans rounded transition-all cursor-pointer ${
                preferences.theme === 'light'
                  ? 'bg-white text-stone-950 font-medium shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
              title="Modern White Contrast"
              id="theme-light-btn"
            >
              Wht
            </button>
            <button
              onClick={() => setTheme('slate')}
              className={`px-2 py-1 text-xs font-sans rounded transition-all cursor-pointer ${
                preferences.theme === 'slate'
                  ? 'bg-slate-800 text-slate-100 font-medium shadow-xs'
                  : 'text-stone-500 hover:text-stone-300'
              }`}
              title="Deep Slate Contrast"
              id="theme-slate-btn"
            >
              Slt
            </button>
          </div>

          {/* Font Resizing controls */}
          <div className="flex items-center gap-0.5 border-l border-stone-200 pl-3">
            <Type className="w-3.5 h-3.5 text-stone-400 mr-1.5" />
            <div className="flex gap-0.5">
              {(['sm', 'base', 'lg', 'xl'] as const).map((sz) => (
                <button
                  key={sz}
                  onClick={() => setFontSize(sz)}
                  className={`w-5 h-5 text-[10px] font-mono rounded flex items-center justify-center transition-all cursor-pointer uppercase ${
                    preferences.fontSize === sz
                      ? 'bg-stone-800 text-white font-bold'
                      : 'text-stone-500 hover:bg-stone-100'
                  }`}
                  id={`font-size-${sz}`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          {/* Saved Bookmarks button */}
          <button
            onClick={onOpenBookmarks}
            className="relative p-1.5 text-stone-600 hover:text-stone-950 rounded hover:bg-stone-100 cursor-pointer transition-all"
            title="Saved Notes & Bookmarks"
            id="open-bookmarks-drawer"
          >
            <Bookmark className="w-4.5 h-4.5 stroke-[2]" />
            {bookmarksCount > 0 && (
              <span className="absolute -top-1 -right-1.5 bg-rose-600 text-white rounded-full font-mono font-bold text-[9px] w-4 h-4 flex items-center justify-center animate-bounce">
                {bookmarksCount}
              </span>
            )}
          </button>
        </div>
      </nav>

      {/* Progress bar overlay */}
      <div className="fixed top-[45px] left-0 w-full h-[3px] bg-stone-100 z-50">
        <div
          className="h-full bg-stone-800 transition-all duration-75"
          style={{ width: `${scrollProgress}%` }}
        ></div>
      </div>
    </>
  );
}
