import React, { useState } from 'react';
import { QuizQuestion, ThemeMode } from '../types';
import { Award, RefreshCw, BarChart2, CheckCircle2, ArrowRight, HelpCircle, UserCheck } from 'lucide-react';

const RESILIENCE_QUIZ: QuizQuestion[] = [
  {
    id: 'q1',
    category: 'adaptive',
    question: 'An AI tool is introduced at your job that can do 60% of your daily report writing and paperwork. What do you do?',
    options: [
      {
        text: 'Keep doing everything manually like you always did. You prefer the old way and want to stick to your usual routine.',
        score: 1,
        feedback: 'Sticking completely to the old way can make it hard to keep up when your workplace changes.'
      },
      {
        text: 'Learn how to use the AI tool well. Let it write the drafts, and use your saved time to focus on solving bigger problems for your team.',
        score: 4,
        feedback: 'Great choice! Letting tools do the simple drafts gives you more time to focus on strategy and leadership.'
      },
      {
        text: 'Change departments to do purely hands-on or physical work where computers cannot help.',
        score: 2,
        feedback: 'Physical work is very safe from AI, but running away from tech might limit your office career choices.'
      }
    ]
  },
  {
    id: 'q2',
    category: 'cognitive',
    question: 'An AI tool suggests a new business idea. You don\'t agree with it at first, but the data says it has a very high chance of working. What do you do?',
    options: [
      {
        text: 'Trust the AI completely and do exactly what it says, believing the computer is always smarter than humans.',
        score: 1,
        feedback: 'Don\'t follow AI blindly! Computers can still make mistakes or have hidden biases in their calculations.'
      },
      {
        text: 'Ignore the suggestion completely. You believe human gut feelings are always better than a computer program\'s numbers.',
        score: 2,
        feedback: 'Being too skeptical can make you miss really good, data-driven ideas that could help your business.'
      },
      {
        text: 'Test the idea on a small scale first. Check the numbers, understand why the AI suggested it, and combine its logic with your own experience to make the final choice.',
        score: 4,
        feedback: 'Perfect! Combining the computer\'s speed with your human judgment leads to the safest and best decisions.'
      }
    ]
  },
  {
    id: 'q3',
    category: 'social',
    question: 'Your clients want friendly human contact, but they also want instant replies 24/7. How do you solve this?',
    options: [
      {
        text: 'Replace all customer service with AI chatbots to save money and handle questions instantly.',
        score: 1,
        feedback: 'Fake empathy can frustrate clients. For big issues, people still want real human care.'
      },
      {
        text: 'Use an AI chatbot to answer simple questions instantly, but make sure a real person quickly takes over for complex or emotional problems.',
        score: 4,
        feedback: 'Smart choice! Let machines handle the fast, simple questions while you handle the deep human connections.'
      },
      {
        text: 'Do not use chatbots at all. Make your clients wait until office hours so everything is handled by a human.',
        score: 2,
        feedback: 'While full human service is nice, making clients wait hours for simple answers can make them unhappy.'
      }
    ]
  },
  {
    id: 'q4',
    category: 'technical',
    question: 'Where are you spending most of your time when trying to learn new skills for your career?',
    options: [
      {
        text: 'Memorizing the exact steps and codes of one specific software program.',
        score: 2,
        feedback: 'Tech programs change fast. Just memorizing buttons or codes can quickly become outdated.'
      },
      {
        text: 'Learning how to adapt quickly, write good prompts, think creatively, and communicate well with people.',
        score: 4,
        feedback: 'Perfect! Having good judgment, learning easily, and managing AI tools well is what keeps you irreplaceable.'
      },
      {
        text: 'Doing nothing new, and just relying on your university degree or current job title to stay safe.',
        score: 1,
        feedback: 'Relying only on old degrees can be risky. Modern work requires us to keep learning new tools.'
      }
    ]
  }
];

const categoryDisp: Record<string, string> = {
  adaptive: "Adaptation",
  cognitive: "Thinking",
  social: "Relations",
  technical: "Learning",
};

export default function ResilienceAssessment({ theme }: { theme: ThemeMode }) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [quizComplete, setQuizComplete] = useState(false);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);

  const handleOptionSelect = (optionIndex: number) => {
    setSelectedOptionIndex(optionIndex);
  };

  const handleNext = () => {
    if (selectedOptionIndex === null) return;
    
    const selectedScore = RESILIENCE_QUIZ[currentQuestionIndex].options[selectedOptionIndex].score;
    const newAnswers = [...answers, selectedScore];
    setAnswers(newAnswers);

    if (currentQuestionIndex < RESILIENCE_QUIZ.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedOptionIndex(null);
    } else {
      setQuizComplete(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestionIndex(0);
    setAnswers([]);
    setSelectedOptionIndex(null);
    setQuizComplete(false);
  };

  // Profile calculations
  const totalScore = answers.reduce((acc, curr) => acc + curr, 0);
  const maxPossible = RESILIENCE_QUIZ.length * 4;
  const ratingPercentage = Math.round((totalScore / maxPossible) * 100);

  let profileBadge = 'The Traditional Expert';
  let profileDescription = '';
  let focusAdvise = '';

  if (ratingPercentage > 85) {
    profileBadge = 'The AI Director';
    profileDescription = 'You manage AI tools with great judgment and human empathy. You guide technology instead of fearing it.';
    focusAdvise = 'Fantastic! Keep using AI to speed up your work, but always remember to double-check its outputs with your own eyes.';
  } else if (ratingPercentage > 60) {
    profileBadge = 'The Helpful Learner';
    profileDescription = 'You use AI when it helps, but you are still figuring out how to let the computer do more of your boring daily tasks.';
    focusAdvise = 'Try focusing more on human connection, talking, and learning how to give better prompt guides to your AI tools.';
  } else if (ratingPercentage > 40) {
    profileBadge = 'The Traditional Expert';
    profileDescription = 'You prefer doing your tasks the old way. You might fear that AI makes human work less important.';
    focusAdvise = 'Start small: let an AI summarize a long page for you. See how it saves you time so you can focus on the fun parts of your job.';
  } else {
    profileBadge = 'The Shy Beginner';
    profileDescription = 'You are a bit nervous about new technologies and rely mostly on traditional ways of working.';
    focusAdvise = 'Don\'t worry! Treat AI like a friendly, helpful helper. Let it do the boring drafts while you guide it and make it perfect.';
  }

  // Visual Styling depending on container theme
  const containerStyle = 
    theme === 'slate'
      ? 'bg-slate-900 border-slate-800 text-slate-100'
      : theme === 'cream'
      ? 'bg-[#f5eeda]/60 border-stone-300 text-stone-900'
      : 'bg-stone-50 border-stone-200 text-stone-900';

  const cardStyle =
    theme === 'slate'
      ? 'bg-slate-850 border-slate-750'
      : 'bg-white border-stone-200/80';

  return (
    <div className={`p-6 md:p-8 rounded-xl border ${containerStyle} shadow-lg transition-colors duration-300 my-10`} id="skills-assessment-tool">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-stone-200/50 pb-5 mb-6">
        <div>
          <div className="flex items-center gap-1.5">
            <UserCheck className="w-4 h-4 text-amber-700 font-bold" />
            <span className="text-[10px] tracking-wider uppercase font-mono font-bold text-amber-800">
              Interactive Career Quiz
            </span>
          </div>
          <h3 className="font-serif text-xl md:text-2xl font-bold mt-1">
            Are You Ready for the AI Future?
          </h3>
          <p className="text-xs text-stone-500 font-sans mt-0.5">
            See how prepared you are for changes at work, and learn how to use AI as your helper.
          </p>
        </div>
        {!quizComplete && (
          <span className="text-xs font-mono bg-stone-200/70 text-stone-700 px-3 py-1 rounded-full">
            Question {currentQuestionIndex + 1} of {RESILIENCE_QUIZ.length}
          </span>
        )}
      </div>

      {!quizComplete ? (
        <div className="space-y-6">
          <div className="py-2">
            <span className="text-xs font-mono uppercase bg-amber-100 text-amber-900 px-2 py-0.5 rounded-sm mb-2.5 inline-block">
              Category: {categoryDisp[RESILIENCE_QUIZ[currentQuestionIndex].category] || RESILIENCE_QUIZ[currentQuestionIndex].category} skills
            </span>
            <p className="font-serif text-base md:text-lg font-semibold leading-relaxed mt-1">
              {RESILIENCE_QUIZ[currentQuestionIndex].question}
            </p>
          </div>

          <div className="space-y-3">
            {RESILIENCE_QUIZ[currentQuestionIndex].options.map((opt, oIdx) => (
              <button
                key={oIdx}
                onClick={() => handleOptionSelect(oIdx)}
                className={`w-full text-left p-4 rounded-lg border text-sm transition-all flex items-start gap-3 cursor-pointer ${
                  selectedOptionIndex === oIdx
                    ? 'border-amber-600 bg-amber-50/40 text-stone-900 shadow-sm ring-1 ring-amber-500'
                    : 'hover:bg-stone-50 border-stone-200/80 bg-white/50 text-stone-700'
                }`}
                id={`q-${currentQuestionIndex}-opt-${oIdx}`}
              >
                <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 text-xs ${
                  selectedOptionIndex === oIdx ? 'bg-amber-600 text-white' : 'border-stone-300'
                }`}>
                  {String.fromCharCode(65 + oIdx)}
                </div>
                <span className="font-sans leading-relaxed">{opt.text}</span>
              </button>
            ))}
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={handleNext}
              disabled={selectedOptionIndex === null}
              className={`px-5 py-2.5 rounded-lg font-mono text-xs flex items-center gap-2 cursor-pointer transition-all ${
                selectedOptionIndex !== null
                  ? 'bg-stone-900 text-white hover:bg-stone-850'
                  : 'bg-stone-200 text-stone-400 cursor-not-allowed'
              }`}
              id="quiz-next-button"
            >
              <span>{currentQuestionIndex === RESILIENCE_QUIZ.length - 1 ? 'Get Results' : 'Next Question'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-8 animate-fadeIn">
          {/* Quiz results header mapping */}
          <div className={`p-6 rounded-lg border flex flex-col md:flex-row items-center justify-between gap-6 ${cardStyle}`}>
            <div className="space-y-2.5 text-center md:text-left">
              <span className="text-[10px] font-mono uppercase bg-amber-100 text-amber-900 px-2.5 py-1 rounded-sm tracking-widest font-bold">
                Your Career Profile
              </span>
              <h4 className="font-serif text-2xl md:text-3xl font-bold text-stone-950">
                {profileBadge}
              </h4>
              <p className="text-sm text-stone-600 leading-relaxed font-sans max-w-xl">
                {profileDescription}
              </p>
            </div>
            
            {/* Round infographic gauge */}
            <div className="flex flex-col items-center justify-center bg-stone-900 text-white rounded-full w-28 h-28 shrink-0 shadow-lg border-4 border-amber-500">
              <span className="font-mono text-3xl font-extrabold text-amber-400">{ratingPercentage}%</span>
              <span className="text-[9px] font-mono uppercase text-stone-400">Ready for AI</span>
            </div>
          </div>

          {/* Detailed Skill Bars */}
          <div className="space-y-4">
            <h5 className="font-serif text-base font-bold flex items-center gap-1.5 text-stone-900">
              <BarChart2 className="w-4 h-4 text-stone-500" />
              <span>Your Key Skills Scores</span>
            </h5>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1 bg-white p-3.5 rounded border border-stone-200/60">
                <div className="flex justify-between text-xs font-mono text-stone-600">
                  <span className="font-bold">Critical Thinking</span>
                  <span>{ratingPercentage > 75 ? '90%' : '55%'}</span>
                </div>
                <div className="h-2 bg-stone-100 rounded-full overflow-hidden">
                  <div className="h-full bg-stone-830 rounded-full bg-stone-800" style={{ width: ratingPercentage > 75 ? '90%' : '55%' }}></div>
                </div>
                <p className="text-[10px] text-stone-400 font-sans">Checking AI draft statements and making final decisions.</p>
              </div>

              <div className="space-y-1 bg-white p-3.5 rounded border border-stone-200/60">
                <div className="flex justify-between text-xs font-mono text-stone-600">
                  <span className="font-bold">Empathy & Connection</span>
                  <span>{ratingPercentage > 75 ? '85%' : '65%'}</span>
                </div>
                <div className="h-2 bg-stone-100 rounded-full overflow-hidden">
                  <div className="h-full bg-sky-600 rounded-full" style={{ width: ratingPercentage > 75 ? '85%' : '65%' }}></div>
                </div>
                <p className="text-[10px] text-stone-400 font-sans">Talking with clients and focusing on human teamwork.</p>
              </div>

              <div className="space-y-1 bg-white p-3.5 rounded border border-stone-200/60">
                <div className="flex justify-between text-xs font-mono text-stone-600">
                  <span className="font-bold">Willingness to Learn</span>
                  <span>{ratingPercentage > 85 ? '95%' : ratingPercentage > 50 ? '70%' : '40%'}</span>
                </div>
                <div className="h-2 bg-stone-100 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-600 rounded-full" style={{ width: ratingPercentage > 85 ? '95%' : ratingPercentage > 50 ? '70%' : '40%' }}></div>
                </div>
                <p className="text-[10px] text-stone-400 font-sans">How open you are to learning new tools and software.</p>
              </div>

              <div className="space-y-1 bg-white p-3.5 rounded border border-stone-200/60">
                <div className="flex justify-between text-xs font-mono text-stone-600">
                  <span className="font-bold">Managing AI Tools</span>
                  <span>{ratingPercentage > 85 ? '90%' : '50%'}</span>
                </div>
                <div className="h-2 bg-stone-100 rounded-full overflow-hidden">
                  <div className="h-full bg-purple-600 rounded-full" style={{ width: ratingPercentage > 85 ? '90%' : '50%' }}></div>
                </div>
                <p className="text-[10px] text-stone-400 font-sans">Writing clear prompts, coordinating tools, and checking work.</p>
              </div>
            </div>
          </div>

          {/* Actionable Playbook Feedback */}
          <div className="bg-amber-50/70 border-l-4 border-amber-500 rounded p-4 text-stone-900">
            <h5 className="font-serif text-sm font-bold text-amber-950 uppercase tracking-tight flex items-center gap-1.5">
              <Award className="w-4 h-4 text-amber-700" />
              <span>Your Easy Actions Steps</span>
            </h5>
            <p className="text-xs text-stone-700 leading-relaxed mt-1.5 font-sans">
              {focusAdvise}
            </p>
            <ul className="text-xs space-y-1.5 mt-3 text-stone-800 font-mono list-disc pl-4">
              <li>Spend 1 or 2 hours every week trying out different AI tools for fun.</li>
              <li>Practice giving clear, simple instructions to AI assistants.</li>
              <li>Focus on building strong, friendly relationships with friends and clients.</li>
            </ul>
          </div>

          <div className="flex justify-center border-t border-stone-200/50 pt-5">
            <button
              onClick={resetQuiz}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono border border-stone-300 text-stone-600 hover:text-stone-900 bg-white hover:bg-stone-50/80 cursor-pointer transition-all"
              id="reset-quiz-button"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry Skills Assessment</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
